import sqlite3 as sql
conn = sql.connect("univ.db")
cur=conn.cursor()

f=open("University Schema","r")
y=f.read().split(";")
for x in y:
    try:
        cur.execute(x)
    except:
        pass

f=open("smallRelationsInsertFile.sql","r")
y=f.read().split(";")
cur.execute("")
c=0
for x in y:
    try:
        cur.execute(x)
    except:
        pass

conn.commit()
conn.close()
