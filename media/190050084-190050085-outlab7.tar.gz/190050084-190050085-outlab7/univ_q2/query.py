import sqlite3 as sql
import csv
import sys
conn=sql.connect("univ.db")
cur=conn.cursor()


if(sys.argv[1]=="0"):
    s="SELECT * FROM "
    s+=sys.argv[2]
    s+=" WHERE "
    s+=sys.argv[3]
    s+=" = '"
    s+=sys.argv[4]
    s+="'"
    cur.executescript(s)
    h=cur.fetchall()
    for rows in h:
        s=""
        for row in rows:
            s+=str(row)
            s+=","
        print(s[:-1])
        
elif(sys.argv[1]=="1"):
    s="SELECT * FROM "
    s+=sys.argv[2]
    s+=" WHERE "
    s+=sys.argv[3]
    s+=" = @0"
    #s+="%s"
    h=[]
    try:
         cur.execute(s,[sys.argv[4]])
         h=cur.fetchall()
    except :
        pass
    for rows in h:
        s=""
        for row in rows:
            s+=str(row)
            s+=","
        print(s[:-1])


conn.commit()
conn.close()
