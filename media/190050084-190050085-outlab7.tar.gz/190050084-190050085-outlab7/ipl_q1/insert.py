import sqlite3 as sql
import csv
conn=sql.connect("ipl.db")
cur=conn.cursor()
def create(table_name,csv_name):
    a_file = open(csv_name)
    rows = csv.reader(a_file)
    next(rows, None)
    for row in rows:
        s="INSERT INTO "+table_name+" VALUES("
        for i in range(len(row)):
            if(i==0):
                if(row[0].isdigit()):
                    s+=row[0]
                else:
                    s+="'"+row[0]+"'"
            else:
                if(row[i].isdigit()):
                    s+=','+row[i]
                else:
                    s+=",'"+row[i]+"'"
        s+=")"
        try:
            cur.execute(s)
        except:
            pass
create('TEAM','team.csv')
create('MATCH','match.csv')
create('PLAYER','player.csv')
create('PLAYER_MATCH','player_match.csv')
create('BALL_BY_BALL','ball_by_ball.csv')
conn.commit()
conn.close()
