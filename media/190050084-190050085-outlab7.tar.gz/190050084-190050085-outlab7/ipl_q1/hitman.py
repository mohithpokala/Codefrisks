import sqlite3 as sql
conn=sql.connect("ipl.db")
cur=conn.cursor()
s="SELECT PLAYER.player_id,PLAYER.player_name,SUM(CASE WHEN BALL_BY_BALL.runs_scored=6 THEN 1 ELSE 0 END),COUNT(PLAYER.player_id),SUM(CASE WHEN BALL_BY_BALL.runs_scored=6 THEN 1 ELSE 0 END)*1.0/COUNT(PLAYER.player_id) AS var FROM BALL_BY_BALL INNER JOIN PLAYER ON PLAYER.player_id = BALL_BY_BALL.striker GROUP BY PLAYER.player_name ORDER BY var desc,PLAYER.player_name asc"
cur.execute(s) 
h=cur.fetchall()
for i in h:
    print(str(i[0])+','+str(i[1])+','+str(i[2])+','+str(i[3])+','+str(i[4]))

