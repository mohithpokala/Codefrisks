import sqlite3 as sql
conn = sql.connect("ipl.db")
cur=conn.cursor()
cur.execute(    '''
                CREATE TABLE TEAM(
                    team_id   INT,
                    team_name text,
                    PRIMARY KEY(team_id)
                )'''
            )
cur.execute('''
                CREATE TABLE PLAYER(
                    player_id     INT,
                    player_name   text,
                    dob           TIMESTAMP,
                    batting_hand  text,
                    bowling_skill text,
                    country_name  text,
                    PRIMARY KEY(player_id)
                )'''
            )
cur.execute('''
                CREATE TABLE MATCH(
                    match_id     INT,
                    season_year  INT,
                    team1        INT,
                    team2        INT,
                    battedfirst  INT,
                    battedsecond INT,
                    venue_name   text,
                    city_name    text,
                    country_name text,
                    toss_winner  text,
                    match_winner text,
                    toss_name    text,
                    win_type     text,
                    man_of_match INT,
                    win_margin   INT,
                    PRIMARY KEY(match_id),
                    FOREIGN KEY(team1) REFERENCES TEAM(team_id),
                    FOREIGN KEY(team2) REFERENCES TEAM(team_id)
                )'''
            )

cur.execute('''
                CREATE TABLE PLAYER_MATCH(
                    playermatch_key BIGINT,
                    match_id        INT,
                    player_id       INT,
                    batting_hand    text,
                    bowling_skill   text,
                    role_desc       text,
                    team_id         INT,
                    PRIMARY KEY(playermatch_key),
    
                    FOREIGN KEY(match_id) REFERENCES MATCH(match_id),
                    FOREIGN KEY(team_id) REFERENCES TEAM(team_id),
                    FOREIGN KEY(player_id) REFERENCES PLAYER(player_id)
                    )'''
            )
cur.execute('''
                CREATE TABLE BALL_BY_BALL(
                    match_id                 INT,
                    innings_no               INT,
                    over_id                  INT,
                    ball_id                  INT,
                    striker_batting_position INT,
                    runs_scored              INT,
                    extra_runs               INT,
                    out_type                 text,
                    striker                  INT,
                    non_striker              INT,
                    bowler                   INT,
                    FOREIGN KEY(match_id) REFERENCES MATCH(match_id),
                    FOREIGN KEY(bowler) REFERENCES PLAYER(player_id),
                    FOREIGN KEY(striker) REFERENCES PLAYER(player_id),
                    FOREIGN KEY(non_striker) REFERENCES PLAYER(player_id),
                    CONSTRAINT PK_ball PRIMARY KEY (match_id,innings_no,over_id,ball_id)
                )'''
            )
