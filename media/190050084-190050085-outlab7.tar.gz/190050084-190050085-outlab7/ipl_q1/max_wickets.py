import sqlite3 as sql
conn=sql.connect("ipl.db")
cur=conn.cursor()
s="SELECT PLAYER.player_id,PLAYER.player_name,COUNT(out_type) AS var FROM BALL_BY_BALL INNER JOIN PLAYER ON PLAYER.player_id = BALL_BY_BALL.bowler WHERE BALL_BY_BALL.out_type NOT IN ('Not Applicable') GROUP BY PLAYER.player_name ORDER BY var desc,PLAYER.player_name asc  LIMIT 20 "
cur.execute(s) 
h=cur.fetchall()
for i in h:
    print(str(i[0])+','+str(i[1])+','+str(i[2]))

