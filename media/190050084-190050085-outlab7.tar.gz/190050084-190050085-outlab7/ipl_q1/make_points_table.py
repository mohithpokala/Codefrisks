import sqlite3 as sql
import csv
conn=sql.connect("ipl.db")
cur=conn.cursor()

cur.execute(    '''
                CREATE TABLE POINTS_TABLE(
                    team_id   INT,
                    team_name text,
                    points INT,
                    nrr DECIMAL,
                    PRIMARY KEY(team_id)
                )'''
            )


cur.execute("SELECT * FROM TEAM") 
rows=cur.fetchall()

for row in rows:
    s="INSERT INTO POINTS_TABLE VALUES("
    s+=str(row[0])
    s+=",'"
    s+=str(row[1])
    s+="',0,0)"
    cur.execute(s)


cur.execute("SELECT * FROM MATCH") 
rows=cur.fetchall()
for row in rows:
    #print(row[0],row[1],row[2],row[3],row[4],row[5],row[6],row[7],row[8],row[9],row[10],row[11],row[12],row[13],row[14])
    if(row[12]=='Tie'):
        s="UPDATE POINTS_TABLE "
        s+="SET points=points+1 "
        s+="WHERE team_id="
        s+=str(row[2])
        s+=" OR "
        s+="team_id="
        s+=str(row[3])
        s+=";"
        cur.execute(s)
    elif row[12]=='runs':
        s="UPDATE POINTS_TABLE "
        s+="SET points=points+2 "
        s+="WHERE team_id="
        s+=str(row[10])
        s+=";"
        cur.execute(s)
        s="UPDATE POINTS_TABLE "
        s+="SET nrr=ROUND(nrr+"
        de=int(row[14])/20
        de=round(de,2)
        s+=str(de)
        s+=",2) WHERE team_id="
        s+=str(row[10])
        s+=";"
        cur.execute(s)
        s="UPDATE POINTS_TABLE "
        s+="SET nrr=ROUND(nrr-"
        s+=str(de)
        s+=",2) WHERE team_id="
        s+=str(int(row[2])+int(row[3])-int(row[10]))
        s+=";"
        cur.execute(s)
    elif row[12]=='wickets':
        s="UPDATE POINTS_TABLE "
        s+="SET points=points+2 "
        s+="WHERE team_id="
        s+=str(row[10])
        s+=";"
        cur.execute(s)
        s="UPDATE POINTS_TABLE "
        s+="SET nrr=ROUND(nrr+"
        de=int(row[14])/10
        de=round(de,2)
        s+=str(de)
        s+=",2) WHERE team_id="
        s+=str(row[10])
        s+=";"
        cur.execute(s)
        s="UPDATE POINTS_TABLE "
        s+="SET nrr=ROUND(nrr-"
        s+=str(de)
        s+=",2) WHERE team_id="
        s+=str(int(row[2])+int(row[3])-int(row[10]))
        s+=";"
        cur.execute(s)
    elif row[10]=='NULL':
        s="UPDATE POINTS_TABLE "
        s+="SET points=points+1 "
        s+="WHERE team_id="
        s+=str(row[2])
        s+=" OR "
        s+="team_id="
        s+=str(row[3])
        s+=";"
        cur.execute(s)
cur.execute("SELECT * FROM POINTS_TABLE ORDER BY points DESC, nrr DESC") 
h=cur.fetchall()
for i in h:
    print(str(i[0])+','+str(i[1])+','+str(i[2])+','+str(i[3]))

conn.commit()
conn.close()
