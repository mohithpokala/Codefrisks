import sqlite3 as sql
conn=sql.connect("ipl.db")
cur=conn.cursor()
s="SELECT MATCH.venue_name,SUM(BALL_BY_BALL.runs_scored+BALL_BY_BALL.extra_runs)*1.0/COUNT(DISTINCT MATCH.match_id) AS var FROM MATCH INNER JOIN BALL_BY_BALL ON MATCH.match_id = BALL_BY_BALL.match_id GROUP BY MATCH.venue_name ORDER BY var desc"
cur.execute(s)
h=cur.fetchall()
for i in h:
    print(i[0]+','+str(i[1]))

